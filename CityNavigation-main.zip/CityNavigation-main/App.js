import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Image, Text, View } from 'react-native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import art from './assets/art.png';
import mile from './assets/mile.png';
import pier from './assets/pier.png';
import water from './assets/water.png';
import willis from './assets/willis.png';

function ArtScreen() {
  return (
    <View style={styles.container}>
      <Image source={art} style={styles.image} />
    </View>
  );
}

function MileScreen() {
  return (
    <View style={styles.container}>
      <Image source={mile} style={styles.image} />
    </View>
  );
}


function PierScreen() {
  return (
    <View style={styles.container}>
      <Image source={pier} style={styles.image} />
    </View>
  );
}

function WaterScreen() {
  return (
    <View style={styles.container}>
      <Image source={water} style={styles.image} />
    </View>
  );
}

function WillisScreen() {
  return (
    <View style={styles.container}>
      <Image source={willis} style={styles.image} />
    </View>
  );
}


const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Art">
        <Drawer.Screen name="Art" component={ArtScreen} options={{ title: 'Art Institute of Chicago' }}/>
        <Drawer.Screen name="Mile" component={MileScreen} options={{ title: 'Magnificent Mile' }}/>
        <Drawer.Screen name="Pier" component={PierScreen} options={{ title: 'Navy Pier' }}/>
        <Drawer.Screen name="Water" component={WaterScreen} options={{ title: 'Water Tower' }}/>
        <Drawer.Screen name="Willis" component={WillisScreen} options={{ title: 'Willis Tower' }}/>
      </Drawer.Navigator>
    </NavigationContainer>
    );
  }
  
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: 320, //400,
    height: 480, //600,
  },
});
